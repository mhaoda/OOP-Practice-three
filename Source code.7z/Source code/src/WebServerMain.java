
/*
 * this is the main class of the server
 */
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class WebServerMain {
	public static void main(String[] args) {
		if(args.length!=2) {
		System.out.println("Usage: java WebServerMain <document_root> <port>");
		System.exit(0);
	}
//		args = new String[2];
//		args[0] = "./www";
//		args[1] = "12345";

		int port = Integer.parseInt(args[1]);
		ServerSocket server = null;
		Socket socket = null;

		try {
			int threadCount = 0;
			server = new ServerSocket(port);
			while (true) {
				socket = server.accept();
				ConnectionHandler handler = new ConnectionHandler(socket, args[0]);
				handler.start();
				threadCount++;
				//close the server when the number of request over 1000
				if (threadCount == 1000) {
					server.close();
					return;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
