
/*
 * This is the class for the handle the connection between the server and the client.
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConnectionHandler extends Thread {

	private Socket conn; // socket representing TCP/IP connection to Client
	private InputStream is; // get data from client on this input stream
	private OutputStream os; // can send data back to the client on this output stream
	private BufferedReader br; // use buffered reader to read client data
	private String dir; // the directory of the resources
	private PrintStream ps; // can send data back to the client on this output stream

	public ConnectionHandler(Socket conn, String dir) {
		this.conn = conn;
		this.dir = dir;
		try {

			is = conn.getInputStream(); // get data from client on this input stream
			os = conn.getOutputStream(); // to send data back to the client on this stream
			br = new BufferedReader(new InputStreamReader(is)); // use buffered reader to read client data
			ps = new PrintStream(os); //// to send data back to the client on this stream
		} catch (IOException ioe) {
			System.out.println("ConnectionHandler: " + ioe.getMessage());
		}
	}

	public void run() { // run method is invoked when the Thread's start method (ch.start(); in Server
						// class) is invoked
		try {
			String request = br.readLine();
			requestSolver(request);
			cleanup();
		} catch (Exception e) { // exit cleanly for any Exception (including IOException,
								// ClientDisconnectedException)
			// System.out.println("ConnectionHandler:run " + e.getMessage());
			cleanup(); // cleanup and exit
		}
	}

	// address the request from the client, the @param is the request received from
	// the client.
	public void requestSolver(String request) {
		System.out.println(request);
		String requestType = request.substring(0, 4); // get the type of the request like GET, HEAD.
		String responseCode = null; // initialise the response code

		// in the case of the GET request
		if (requestType.contains("GET")) {
			String requestAddress = null;
			String requestFile = null;

			// generate the request file address depends on diverse type of the requested
			// file.
			if (request.contains("html")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".html"));
				requestAddress = dir + requestFile + ".html";
			}
			if (request.contains("jpg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jpg"));
				requestAddress = dir + requestFile + ".jpg";
			}
			if (request.contains("jepg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jepg"));
				requestAddress = dir + requestFile + ".jepg";
			}
			if (request.contains("gif")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".gif"));
				requestAddress = dir + requestFile + ".gif";
			}
			if (request.contains("png")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".png"));
				requestAddress = dir + requestFile + ".png";
			}

			// get the file by the requested file address
			File file = new File(requestAddress);

			// if the file exists, the response code returns to 200.
			if (file.exists()) {
				String contentType = null;
				responseCode = "HTTP/1.1 200 OK";
				ps.println("HTTP/1.1 200 OK");

				// set the content type
				if (requestAddress.contains(".html")) {
					ps.println("Content-Type: text/html");
					contentType = "Content-Type: text/html";
				}
				if (requestAddress.contains(".jpg")) {
					ps.println("Content-Type: image/jpg");
					contentType = "Content-Type: image/jpg";
				}
				if (requestAddress.contains(".jpeg")) {
					ps.println("Content-Type: image/jpeg");
					contentType = "Content-Type: image/jpeg";
				}
				if (requestAddress.contains(".gif")) {
					ps.println("Content-Type: image/gif");
					contentType = "Content-Type: image/gif";
				}
				if (requestAddress.contains(".png")) {
					ps.println("Content-Type: image/png");
					contentType = "Content-Type: image/png";
				}

				// set the content length
				ps.println("Content-Length: " + file.length());
				// send the information body to client
				sendFile(file);
			} else {

				// if the requested does not exist, response returns to 404
				responseCode = "HTTP/1.1 404 Not Found";
				ps.println("HTTP/1.1 404 Not Found");
			}
		}

		// in the case of the HEAD request
		if (requestType.contains("HEAD")) {
			String requestAddress = null;
			String requestFile = null;

			// generate the request file address depends on diverse type of the requested
			// file.
			if (request.contains("html")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".html"));
				requestAddress = dir + requestFile + ".html";
			}
			if (request.contains("jpg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jpg"));
				requestAddress = dir + requestFile + ".jpg";
			}
			if (request.contains("jepg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jepg"));
				requestAddress = dir + requestFile + ".jepg";
			}
			if (request.contains("gif")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".gif"));
				requestAddress = dir + requestFile + ".gif";
			}
			if (request.contains("png")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".png"));
				requestAddress = dir + requestFile + ".png";
			}

			// get the file by the requested file address
			File file = new File(requestAddress);

			// if the file exists, the response code returns to 200.
			if (file.exists()) {
				String contentType = null;
				responseCode = "HTTP/1.1 200 OK";
				ps.println("HTTP/1.1 200 OK");

				// set the content type
				if (requestAddress.contains(".html")) {
					ps.println("Content-Type: text/html");
					contentType = "Content-Type: text/html";
				}
				if (requestAddress.contains(".jpg")) {
					ps.println("Content-Type: image/jpg");
					contentType = "Content-Type: image/jpg";
				}
				if (requestAddress.contains(".jpeg")) {
					ps.println("Content-Type: image/jpeg");
					contentType = "Content-Type: image/jpeg";
				}
				if (requestAddress.contains(".gif")) {
					ps.println("Content-Type: image/gif");
					contentType = "Content-Type: image/gif";
				}
				if (requestAddress.contains(".png")) {
					ps.println("Content-Type: image/png");
					contentType = "Content-Type: image/png";
				}

				// set the content length
				ps.println("Content-Length: " + file.length());

			} else {

				// if the requested does not exist, response returns to 404
				responseCode = "HTTP/1.1 404 Not Found";
				ps.println("HTTP/1.1 404 Not Found");
			}
		}
		// in the case of the DELETE request
		if (requestType.contains("DELETE")) {
			String requestAddress = null;
			String requestFile = null;

			// generate the request file address depends on diverse type of the requested
			// file.
			if (request.contains("html")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".html"));
				requestAddress = dir + requestFile + ".html";
			}
			if (request.contains("jpg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jpg"));
				requestAddress = dir + requestFile + ".jpg";
			}
			if (request.contains("jepg")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".jepg"));
				requestAddress = dir + requestFile + ".jepg";
			}
			if (request.contains("gif")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".gif"));
				requestAddress = dir + requestFile + ".gif";
			}
			if (request.contains("png")) {
				requestFile = request.substring(request.indexOf("/"), request.indexOf(".png"));
				requestAddress = dir + requestFile + ".png";
			}

			// get the file by the requested file address
			File file = new File(requestAddress);

			// if the file exists, then delete is from the resources folder
			if (file.exists() && file.isFile()) {
				file.delete();
				responseCode = "HTTP/1.1 301 Moved Permanently";
			} else {
				responseCode = "HTTP/1.1 404 Not Found";
			}
		}

		// if the request is unknown, response code returns to 501
		if (!requestType.contains("GET") && !requestType.contains("HEAD") && !requestType.contains("DELETE")) {
			responseCode = "HTTP/1.1 501 Not Implemented";
			ps.println("HTTP/1.1 501 Not Implemented");
		}

		// log the request information into a file
		Logging(requestType, responseCode);
	}

	// the method for sending the information body to client, the @param is the
	// requested file by client
	private void sendFile(File file) {
		try {
			DataInputStream dataIn = new DataInputStream(new FileInputStream(file)); // get data from the file
			byte[] b = new byte[(int) file.length()]; // initialise a byte array to store the file data
			dataIn.readFully(b); // put file data into the byte array
			ps.println(""); // change the line after response header
			ps.write(b); // send back to client
			ps.flush(); // clear buffer data
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// the method for logging the request information, two @param are request type
	// and the response code
	private void Logging(String requestType, String responseCode) {
		Date d = new Date(); // get the date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // set the format of the date
		String date = sdf.format(d) + " " + " " + requestType + responseCode; // generate the request information
		FileOutputStream o = null;
		String filename = "data.txt"; // the file used to store the request information
		byte[] buff = new byte[] {};
		try {
			File file = new File(filename);

			// if the file does not exist, create the file
			if (!file.exists()) {
				file.createNewFile();
			}
			buff = date.getBytes();
			o = new FileOutputStream(file, true); // output the data append to fore data
			o.write(buff); // write data into the file
			String newLine = System.getProperty("line.separator");
			o.write(newLine.getBytes()); // change the line
			o.flush(); // clear buffer data
			o.close(); // close out put stream
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// close all
	private void cleanup() {
		try {
			br.close();
			is.close();
			conn.close();
		} catch (IOException ioe) {
			System.out.println("ConnectionHandler:cleanup " + ioe.getMessage());
		}
	}

}
